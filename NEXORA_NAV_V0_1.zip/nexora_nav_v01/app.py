from flask import Flask, jsonify, render_template
from datetime import datetime, timezone

app = Flask(__name__)

# Synthetic demo data only. These are not real vehicle positions or routes.
DEMO_OBJECTS = [
    {"id": "AIR-01", "kind": "aircraft", "label": "Passenger aircraft", "lat": 28.0, "lon": 20.0, "alt": "Demo altitude"},
    {"id": "SEA-01", "kind": "ship", "label": "Civilian ship", "lat": -5.0, "lon": 95.0, "alt": "Demo status"},
    {"id": "RAIL-01", "kind": "train", "label": "Passenger train", "lat": 42.0, "lon": -75.0, "alt": "Demo status"},
    {"id": "ROAD-01", "kind": "car", "label": "Road vehicle", "lat": -25.0, "lon": -45.0, "alt": "Demo status"},
]

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/status")
def status():
    return jsonify({
        "project": "NEXORA NAV",
        "version": "0.1.0",
        "mode": "SIMULATION ONLY",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "notice": "Synthetic educational data; not for real navigation.",
        "objects": DEMO_OBJECTS
    })

@app.route("/health")
def health():
    return jsonify({"ok": True, "service": "nexora-nav"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)

# NEXORA NAV V0.1 — सुरक्षित नागरिक रिसर्च सिमुलेशन

यह Python + JavaScript आधारित वेब डेमो है। इसमें 3D ग्लोब, चार काल्पनिक परिवहन ऑब्जेक्ट, GNSS उपलब्धता का डेमो स्विच और डेटा-विश्वसनीयता का उदाहरण शामिल है।

## महत्वपूर्ण सुरक्षा सीमा
- यह वास्तविक GPS/नेविगेशन सिस्टम नहीं है।
- इसमें वास्तविक वाहन की स्थिति, वास्तविक मार्ग, सेंसर फ्यूजन या वाहन नियंत्रण नहीं है।
- विमान, जहाज, ट्रेन, कार या ड्रोन को चलाने के लिए इसका उपयोग न करें।
- प्रतिशत केवल UI डेमो मान हैं, वैज्ञानिक माप नहीं।

## 1. Termux या Linux में चलाना

```bash
pkg update -y
pkg install python git -y
```

प्रोजेक्ट फोल्डर में जाएं और चलाएं:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

ब्राउज़र में खोलें:

```text
http://127.0.0.1:5000
```

## 2. Cloud पर मुफ्त शुरुआत

1. इस ZIP को extract करें।
2. GitHub पर नया repository बनाएं।
3. इस फोल्डर की सभी फाइलें repository में upload करें।
4. Render पर account बनाकर GitHub repository connect करें।
5. Web Service बनाएं; Build Command: `pip install -r requirements.txt`
6. Start Command: `gunicorn app:app`
7. Deploy पूरा होने पर Render का दिया HTTPS URL Android Chrome में खोलें।

ध्यान दें: Cloud providers की free-tier शर्तें बदल सकती हैं; free service sleep, usage limits या verification मांग सकती है। कोई भुगतान योजना चुनने से पहले कीमत जांचें।

## 3. फोल्डर संरचना

```text
nexora_nav_v01/
├── app.py
├── requirements.txt
├── Procfile
├── render.yaml
├── README_HI.md
├── templates/
│   └── index.html
└── static/
    ├── app.js
    └── style.css
```

## 4. API जांच

चलने के बाद:
- `/health` — सर्वर स्वास्थ्य
- `/api/status` — काल्पनिक सिमुलेशन डेटा

## 5. अगला वैज्ञानिक चरण

डेमो के बाद वास्तविक शोध कार्य होगा: मेट्रिक्स की परिभाषा, संदर्भ डेटा, परीक्षण परिस्थितियां, त्रुटि विश्लेषण, और विशेषज्ञ समीक्षा। इस डेमो के UI प्रतिशत को वास्तविक accuracy न समझें।

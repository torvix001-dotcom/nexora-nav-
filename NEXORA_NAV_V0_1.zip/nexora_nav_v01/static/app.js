import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";

const globeHost = document.getElementById("globe");
let scene, camera, renderer, earth, markerGroup;
const markers = [];
const colors = {air:0x55b7ff, ship:0x50d6a2, train:0xc59cff, car:0xffc76a};
const symbols = {aircraft:"✈️", ship:"🚢", train:"🚆", car:"🚗"};

function makeGlobe(){
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(45, globeHost.clientWidth/globeHost.clientHeight, .1, 100);
  camera.position.set(0,0,3.2);
  renderer = new THREE.WebGLRenderer({antialias:true, alpha:true});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
  renderer.setSize(globeHost.clientWidth,globeHost.clientHeight);
  globeHost.appendChild(renderer.domElement);

  scene.add(new THREE.AmbientLight(0xffffff,1.3));
  const light = new THREE.DirectionalLight(0xffffff,2.2); light.position.set(4,3,5); scene.add(light);

  const geometry = new THREE.SphereGeometry(1,64,64);
  const material = new THREE.MeshStandardMaterial({color:0x1d5b87, roughness:.88, metalness:.05});
  earth = new THREE.Mesh(geometry,material); scene.add(earth);

  const wire = new THREE.Mesh(new THREE.SphereGeometry(1.006,32,24),
    new THREE.MeshBasicMaterial({color:0x58bfff,wireframe:true,transparent:true,opacity:.10}));
  scene.add(wire);
  markerGroup = new THREE.Group(); scene.add(markerGroup);

  const starsGeo = new THREE.BufferGeometry();
  const points=[];
  for(let i=0;i<500;i++){points.push((Math.random()-.5)*9,(Math.random()-.5)*6,(Math.random()-.5)*5-1.5);}
  starsGeo.setAttribute("position",new THREE.Float32BufferAttribute(points,3));
  scene.add(new THREE.Points(starsGeo,new THREE.PointsMaterial({color:0x9ccfff,size:.012})));

  const animate=()=>{requestAnimationFrame(animate);earth.rotation.y+=.0008;markerGroup.rotation.y+=.0008;renderer.render(scene,camera);};
  animate();
  window.addEventListener("resize",resizeGlobe);
}
function resizeGlobe(){
  if(!renderer)return;
  const w=globeHost.clientWidth,h=globeHost.clientHeight;
  camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h);
}
function toXYZ(lat,lon,r=1.025){
  const phi=(90-lat)*Math.PI/180, theta=(lon+180)*Math.PI/180;
  return new THREE.Vector3(-r*Math.sin(phi)*Math.cos(theta),r*Math.cos(phi),r*Math.sin(phi)*Math.sin(theta));
}
function addMarkers(objects){
  markerGroup.clear();markers.length=0;
  objects.forEach(o=>{
    const mesh=new THREE.Mesh(new THREE.SphereGeometry(.025,16,16),
      new THREE.MeshBasicMaterial({color:colors[o.kind]||0xffffff}));
    mesh.position.copy(toXYZ(o.lat,o.lon));markerGroup.add(mesh);markers.push(mesh);
  });
}
function renderCards(objects){
  const host=document.getElementById("vehicleCards");
  host.innerHTML=objects.map(o=>`<div class="card"><div class="emoji">${symbols[o.kind]||"●"}</div><strong>${o.label}</strong><small>${o.id} · काल्पनिक डेमो</small></div>`).join("");
}
async function loadData(){
  const server=document.getElementById("serverStatus");
  try{
    const res=await fetch("/api/status"); if(!res.ok)throw new Error("API unavailable");
    const data=await res.json();
    server.textContent="ONLINE";
    document.getElementById("serverTime").textContent="UTC: "+new Date(data.timestamp_utc).toLocaleTimeString();
    addMarkers(data.objects);renderCards(data.objects);
  }catch(e){server.textContent="OFFLINE";document.getElementById("serverTime").textContent="API से संपर्क नहीं हुआ";}
}
function updateDemoState(){
  const gnss=document.getElementById("gnssToggle").checked;
  const offline=document.getElementById("offlineToggle").checked;
  const value=offline?82:(gnss?98:76);
  document.getElementById("confidence").textContent=`Demo: ${value}%`;
  document.getElementById("confidenceBar").style.width=value+"%";
  document.getElementById("confidenceTag").textContent=offline?"OFFLINE DEMO":(gnss?"GNSS AVAILABLE DEMO":"GNSS UNAVAILABLE DEMO");
  document.getElementById("integrity").textContent=offline?"LOCAL DEMO DATA":(gnss?"SIMULATED / CHECKED":"LIMITED DEMO INFORMATION");
  document.getElementById("integrityNote").textContent="सिमुलेशन स्थिति; वास्तविक माप नहीं।";
}
makeGlobe();
loadData();
document.getElementById("gnssToggle").addEventListener("change",updateDemoState);
document.getElementById("offlineToggle").addEventListener("change",updateDemoState);
document.getElementById("refreshBtn").addEventListener("click",loadData);
document.getElementById("resetView").addEventListener("click",()=>{camera.position.set(0,0,3.2);camera.lookAt(0,0,0);});
updateDemoState();
